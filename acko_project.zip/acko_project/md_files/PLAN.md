# PLAN.md — Contract Guard

> Gate 1 plan. Later changes are recorded in `DECISIONS.md`, as required by the assessment.

## 1. The problem in my own words

**Users:** engineers who own the three provider APIs (Quotes, Policy, Claims), engineers in the four consumer services (Mobile, Partner Integrations, Payments, Notifications), and platform leads.

**Outcome that matters:** no API change silently breaks a calling service. A team uploads a new OpenAPI version (or a changed consumer YAML); Contract Guard resolves `$ref`, diffs the **effective** request/response shapes against the **last accepted version**, checks which services would break, returns **SAFE / WARN / BLOCKED**, notifies the concerned teams through the webhook receiver, and records every attempt for review. Notifications for blocks and warnings carry the full reason, related services, provider API, exact request/response field/spec location, and who must act.

## 2. Questions asked to the product owner, and answers

Full log with timestamps: `DECISIONS.md`. Key points:

1. Dependencies are consumer service → provider API; the consumer `team:` field identifies who to notify.
2. "API key" was a slip — the product is about API contract changes, not credentials.
3. `$ref` is an internal OpenAPI reference; compare effective shapes, not file organisation.
4. Severity/notification: CRITICAL (accessed field/parameter removed or changed, new required send field missing, semantic error) = BLOCK + notify **only the API owner team**; changed/removed but unused = WARNING to the service team; added fields = informational (both teams for response additions, service team for request extras).
5. Invalid specs (including broken `$ref`) are rejected with a clear error reported to the user.
6. `x-internal` / `x-sunset` are OpenAPI extensions. Workflow was delegated to me and approved: internal operations excluded from impact checks unless a registered consumer uses them; sunset rules per the owner's latest instructions.
7. An accessed parameter rename is CRITICAL; every CRITICAL prevents deployment.
8. Two separate frontend upload fields: consumer YAML and API spec YAML.
9. Versions are processed sequentially; a blocked version does not stop a later safe version from deploying.
10. Comparison baseline: **last accepted version currently in use** — rejected and blocked versions never become the baseline.
11. Semantic error: a new update whose version name has already been **accepted** — CRITICAL. A rejected version's name does not count.
12. Consumer-side upload: a removed required `sends` field blocks; other cases warn and notify the other team.
13. Stack: **Spring Boot + Maven + Jackson YAML + Thymeleaf**, H2 persistence.

## 3. What I learned from researching similar real products

- **oasdiff** classifies 784 OpenAPI changes; severity comes from contract direction and effect on valid messages: narrowing a request is breaking, widening a response is breaking; violating a deprecation promise is breaking by policy; when impact cannot be proven it reports breaking. It supports severity overrides and a CI review gate.
- Takeaways: classify by request/response direction, requiredness, type, enum and constraints; keep one explicit rule table; treat sunset promises as policy rules; prefer blocking when impact cannot be proven.
- Difference: we add a consumer usage registry, so severity depends on **actual usage**, and we gate the **registry publish**, not just a CI diff. Our rule set deliberately follows the product owner where it differs from generic tools (an added response field is only informational here).

## 4. Must-haves and scope

| # | Must-have | Implementation |
|---|---|---|
| 1 | Service/spec registry | H2 tables; services registered via API/UI/kit import; YAML/JSON upload via **API and UI**; validation errors returned. |
| 2 | Shared components | Recursive `$ref` resolution with cycle guard and depth limit; compare flattened effective shapes. |
| 3 | Comparing versions | Diff endpoints/methods, parameters, request/response fields incl. `[]`, type, required, enum, constraints, status codes. |
| 4 | Classifying changes | `Classifier` rule table; plain-English reason with API, spec pointer, affected services. |
| 5 | Consumers | Four consumer YAMLs registered via kit import or upload. |
| 6 | Impact | Findings list affected consumers per change. |
| 7 | Publishing safely | Any CRITICAL → BLOCKED, review id, API owner notified. |
| 8 | Changelog/history | Any-pair diff; attempt history and full notification payloads. |
| 9 | UI | Dashboard, two upload forms, diff, history/review, consumers, metrics. |
| 10 | Metrics + runnable | Metrics page + `/api/metrics`; one-command Docker Compose; README. |

**Left out** (going-further items, with reason): AI-written migration guides and a separate CI CLI check — they depend on the core diff/classifier being correct first. No provider→provider dependency graph: the kit has no such data.

## 5. Finalized system design

### Stack and deployment

- **Java 17 / Spring Boot 4.1.2**, Maven, **Jackson YAML** (`jackson-dataformat-yaml`), **Thymeleaf**, **Spring JDBC + H2** file database.
- `Dockerfile`: multi-stage Maven build → JRE image; copies the starter kit read-only into the image.
- `docker-compose.yml`: app on port 8080 + the kit's webhook receiver on port 9900; `WEBHOOK_URL` points to `http://webhook-receiver:9000/contract-guard`.

### Package / class structure

```
com.acko.contractguard
├── ContractGuardApplication.java
├── model/     Outcome, Severity, ServiceKind, SpecStatus, ServiceRegistration,
│              ConsumerUse, ConsumerRegistration, FieldInfo, ParamInfo,
│              OperationModel, ApiModel, Change, ChangeType, Finding, Decision,
│              SpecVersion, Attempt
├── spec/      SpecParser — YAML/JSON parsing, validation, $ref resolution,
│              schema flattening, consumer-file parsing
├── diff/      Differ — endpoint/parameter/field/status-code diff of two ApiModels
├── rules/     Classifier — severity + recipients from usage and rule table
├── publish/   PublishService — orchestrates validate → diff → classify → decide
│              → persist → notify, for both provider and consumer uploads
├── notify/    WebhookNotifier — POST JSON to the webhook receiver
├── store/     Store — H2/JdbcTemplate schema and queries
└── web/       PageController (Thymeleaf), ApiController (REST)
```

### Provider upload flow

1. Parse YAML/JSON → parse errors are returned to the user and recorded as REJECTED.
2. Validate `openapi`, `info.version`, `paths`, and all local `$ref`s → rejected with clear messages.
3. If an **accepted** version with the same name exists → SEMANTIC ERROR, CRITICAL → BLOCKED.
4. Load the **last accepted** spec; resolve `$ref` on both and flatten to `ApiModel`.
5. `Differ` produces change events; `Classifier` matches them against consumer `sends`/`reads` and assigns severity + recipients.
6. Outcome = worst finding: any CRITICAL → BLOCKED, else any WARNING/NOTICE → WARN, else SAFE. Spec is saved ACCEPTED only when not BLOCKED; a BLOCKED version never becomes the baseline.
7. Persist attempt (review id = attempt id when blocked) and POST a detailed notification to the webhook.

### Consumer upload flow

Parse consumer YAML → for each `uses` entry find the provider's last accepted spec → verify method/path, required request fields the consumer must send, extra fields it sends, and response fields it reads. Removing a required send field → BLOCK (service team must notify the API team); other mismatches → WARN + notify both sides. Non-blocked consumer files are registered.

### Algorithms / rules encoded

- Path templates normalised (`{id}` → `{}`) for endpoint identity, but original parameter names retained to detect renames.
- Field paths use dots and `[]`, matching the consumer file format (`premium.breakdown[].amount`).
- `x-internal` operations: excluded from impact checks; CRITICAL if a registered consumer uses one.
- `x-sunset`: past date on an accessed element → BLOCK; future date → WARNING; newly set past date → BLOCK with instruction to extend; removal before/after sunset handled from the previous field's date.
- Added fields → NOTICE; response additions notify both teams, request extras the service team only.
- Status-code changes → WARNING (consumer files carry no status codes).

### Data model (H2)

- `services(id, name UNIQUE, kind, owner_team)`
- `specs(id, service, version, file_name, raw_yaml, status, uploaded_at)`
- `consumers(id, name UNIQUE, team, uses_json)`
- `attempts(id, service, version, outcome, summary, findings_json, created_at)`
- `notifications(id, attempt_id, payload, sent_at)`

### REST API

`POST /api/services`, `POST /api/specs/upload`, `POST /api/consumers/upload`, `GET /api/specs/{service}/versions`, `GET /api/specs/{service}/diff?from=&to=`, `GET /api/history`, `GET /api/review-queue`, `GET /api/consumers`, `GET /api/metrics`.

### Notification payload

```json
{"kind":"API_SPEC","outcome":"BLOCKED","service":"quote-api","version":"1.1.0",
 "comparisonBaseline":"1.0.0","reason":"1 CRITICAL finding",
 "reviewId":2,"notifiedTeams":["Quotes"],
 "findings":[{"severity":"CRITICAL","type":"PARAMETER_RENAMED","api":"quote-api",
   "field":"id","reason":"... mobile-app uses id ... Specification location: #/paths/...","affectedConsumers":["mobile-app"],"notifyTeams":["Quotes"]}],
 "errors":[],"at":"...","webhookDelivered":true}
```

## 6. Main screens (implemented)

1. **Dashboard** — services, versions, statuses, metrics; **Import services & consumers** and **Replay all spec versions** actions (read-only kit files).
2. **Upload API spec** — last-accepted-version table, service select, file field, outcome badge, findings with reason/affected services/spec location/notify teams, and inline errors.
3. **Upload consumer** — separate file field, outcome badge, findings and errors, registered consumers.
4. **Diff** — any two versions with change table and spec locations.
5. **History & review** — all attempts and full notification payloads.
6. **Consumers** — consumer teams, endpoints, sends/reads.
7. **Metrics** — dangerous changes caught, blocked/warned/safe counts, rejected uploads, notifications.

## 7. Test plan

- **Unit** (`SpecParserTest`): component rename with identical wire shape → no false break; broken `$ref` rejected; field rename detected; sunset dates detected; consumer file parsed.
- **Integration**: upload via API and UI; H2 persistence across restarts; webhook POST delivery; history/changelog retrieval.
- **Acceptance replay (kit, in filename order):**
  - quote 1.1.0: `id`→`quoteId` used by mobile-app and notifications-svc → **BLOCK**; baseline stays 1.0.0.
  - quote 2.0.0: compared with 1.0.0; `breakdown[].amount`→`value` → **BLOCK**.
  - quote 2.1.0: compared with 1.0.0; still blocked by those changes; optional `ncbPercent`/`taxes` are informational.
  - policy 1.1.0: past-sunset `legacyCode` (used by payments-svc) blocks; future-sunset `phone` warns.
  - policy 2.0.0: `legacyCode` removed → BLOCK; 2.1.0: required `requestedBy` missing → BLOCK; `VEHICLE` enum removal → WARNING.
  - claims file 2 (broken `$ref`) → REJECTED; file 3 `1.1.0` is not a duplicate (rejected names don't count) and is compared with 1.0.0; file 4 `amountApproved` becomes optional while mobile-app reads it → BLOCK.
  - Consumer YAML uploads produce the expected BLOCK/WARN/SAFE per §4 rules.

## 8. Metrics

Dangerous changes caught, blocked/warned/safe attempts, rejected uploads, affected consumers per finding, notifications delivered, findings by team.

## 9. Decisions — all finalized

All items formerly open are settled in `DECISIONS.md`: baseline (D-15/D-18), semantic error (D-16/D-19), stack (D-17), notification detail (D-20), frontend (D-21), sequential processing (D-13), consumer-side rules and the delegated `x-internal` workflow (owner approved the proposals). Remaining task is implementation and verification, not design.

## 10. Build order and status

1. Skeleton, store, validation, `$ref` resolver — done.
2. Differ, classifier, publish orchestration, notifier — done.
3. UI with two upload fields, diff, history, consumers, metrics — done.
4. Docker/README, unit tests, acceptance replay — in progress/verification.
5. `PROGRESS.md` and `REVIEW.md` to be written after verification.
