# Contract Guard — Decision log

Status: **CONFIRMED** = ruled by you (product owner); **OPEN** = not yet decided (do not assume); **PROPOSED** = assistant suggestion awaiting approval. Every decision has a UTC timestamp. Later rulings supersede earlier ones.

---

## 1. Basis

| ID | Time | Decision | Status |
|---|---|---|---|
| D-01 | 2026-11-18 13:26 | Dependencies are **consumer service → provider API**, not provider → provider. Providers: quote-api (Quotes), policy-api (Policy), claims-api (Claims). Consumers: mobile-app (Mobile), partner-portal (Partner Integrations), payments-svc (Payments), notifications-svc (Notifications). | CONFIRMED |
| D-02 | 2026-11-18 13:26 | Consumer files contain `sends` (request fields/params) **and** `reads` (response fields); both sides are checked. | CONFIRMED |
| D-03 | 2026-11-18 13:26 | `x-internal` and `x-sunset` are **OpenAPI extensions**, not HTTP headers. | CONFIRMED |

## 2. Severity tiers (latest wording wins)

| ID | Time | Decision | Status |
|---|---|---|---|
| D-04 | 2026-11-18 13:26 | **CRITICAL**: a field is removed or changed while a service accesses/requests it, so it breaks right away; a new required request field a service does not send; a renamed parameter a consumer calls by another name; a semantic error. **Deployment is stopped.** | CONFIRMED |
| D-05 | 2026-11-18 13:50 | For CRITICAL breaks, **notify only the API owner team** (latest rule; supersedes earlier "also notify the service team"). | CONFIRMED |
| D-06 | 2026-11-18 13:50 | Semantic errors are CRITICAL: block deployment and notify the concerned owners. | CONFIRMED — exact list OPEN, Q1 |
| D-07 | 2026-11-18 13:50 | If something is removed or changed but is **not** required/requested by any service → **WARNING** to the requesting team; deployment allowed. "NOTICE" is retained only as the informational label for added fields. | CONFIRMED (latest rules supersede earlier labels) |
| D-08 | 2026-11-18 13:26 | With `additionalProperties: false`, an extra request field a consumer sends becomes CRITICAL. | CONFIRMED |

## 3. API-side rules (uploading a new provider spec)

| Change | Accessed by a consumer? | Result | Notify | Status |
|---|---|---|---|---|
| Field/parameter renamed (request or response, incl. `{id}` → `{quoteId}`) | Yes | **BLOCK** | API owner team only | CONFIRMED |
| Field/parameter renamed | No | WARNING | Service team | CONFIRMED |
| Response field a consumer reads removed | Yes | **BLOCK** | API owner team only | CONFIRMED |
| Response field removed | No | WARNING | Service team | CONFIRMED |
| Response field **added** | — | NOTICE (non-blocking) | **Both** API team and service team | CONFIRMED |
| New **required** request field a consumer does not send | Yes | **BLOCK** | API owner team only | CONFIRMED |
| Extra request field a consumer sends that the API does not require | — | NOTICE | Service team only ("does not matter to the endpoint") | CONFIRMED |
| API removes a request field a consumer still sends | — | WARNING | Service team only | CONFIRMED (owner confirmed #5) |
| Semantic error (type/format/enum/constraints/…) | — | **BLOCK** | Concerned owners | CONFIRMED on severity; list OPEN, Q1 |

## 4. Consumer-side rules (uploading a changed consumer YAML)

Frontend has **two separate upload fields**; each returns **BLOCK / WARN / SAFE**.

| Change | Result | Notify | Status |
|---|---|---|---|
| Consumer **removes** a `sends` field the API requires | **BLOCK** | Service team must notify the API team before requesting | CONFIRMED |
| Consumer adds a `reads` field the API does not return | — | — | OPEN — Q2 |
| Consumer adds an extra `sends` field the API does not require | — | — | OPEN — Q2 |
| Consumer removes a `reads` field | — | — | OPEN — Q2 |
| Consumer changes endpoint path or method | — | — | OPEN — Q2 |

## 5. `x-internal` — PROPOSED (delegated to assistant, awaiting sign-off)

1. Internal operations excluded from consumer-impact checks and public listings.
2. Changes still appear in the changelog, tagged "internal".
3. If a registered consumer uses an internal endpoint → CRITICAL, block, notify API owner team.
4. Otherwise internal changes publish normally.

## 6. `x-sunset` (grouped scenarios; "latest rule" applied)

"Current date of the request" = wall clock at upload/publish time. Kit: `legacyCode` sunset `2026-11-01` (past), `holder.phone` sunset `2027-06-30` (future).

| Situation | Result | Notify | Status |
|---|---|---|---|
| Sunset date past **and** element accessed | **BLOCK** (CRITICAL) | API owner team only (latest CRITICAL rule overrides earlier "both teams") | CONFIRMED |
| Sunset date past **and** element not accessed | WARNING | Service team | CONFIRMED |
| Future sunset date **and** element accessed ("CRITICAL NOTICE") | **BLOCK if it breaks right away**; otherwise warning | API owner team only if breaking; otherwise warning to service | CONFIRMED |
| Future sunset date **and** element not accessed | WARNING, beforehand | Service team | CONFIRMED |
| New version **sets a past** sunset date, element accessed | **BLOCK**, ask API team to extend the date | API owner team | CONFIRMED |
| New version sets a past sunset date, element not accessed | Allow with WARNING for future requests | Service team | CONFIRMED |
| Element removed after its sunset date, consumer still uses it | ASSISTANT PROPOSAL: CRITICAL (no "migrated" state exists) | API owner team | OPEN — Q6 |
| Element removed before its sunset date | ASSISTANT PROPOSAL: CRITICAL (timeline violated) | API owner team | OPEN — Q6 |

## 7. Publishing and review

| ID | Time | Decision | Status |
|---|---|---|---|
| D-09 | 2026-11-18 13:26 | Every CRITICAL blocks deployment of the whole version. | CONFIRMED |
| D-10 | 2026-11-18 13:26 | Blocked publishes are marked for review with: what the error is, how it happened, which services and API teams are concerned. | CONFIRMED |
| D-11 | 2026-11-18 13:26 | Who reviews/overrides; baseline version for the next diff after a block. | PARTIAL — review/override still OPEN, Q7 |
| D-13 | 2026-11-18 13:58 | Versions go **sequentially**; if the previous version was BLOCKED and put for review, a new version that is safe to deploy **can still be deployed** — a block does not carry forward to the next version. | CONFIRMED |
| D-14 | 2026-11-18 13:58 | Preferred implementation stack: **Java / Spring**, if possible. Verified feasible: Java 25, Maven 3.9.16, Maven Central reachable, Docker available. | CONFIRMED (preference) |
| D-15 | 2026-11-18 14:04 | **Comparison baseline = the last accepted version that is currently in use.** A blocked version is not accepted, so it does not advance the baseline. | CONFIRMED |
| D-16 | 2026-11-18 14:04 | **"Semantic error" = a new update whose version name is the same as a previous one** (duplicate `info.version`). Semantic errors are CRITICAL: block + notify concerned owners. | CONFIRMED |
| D-17 | 2026-11-18 14:04 | Stack is fixed: **Spring Boot + Maven + Jackson YAML + Thymeleaf**. | CONFIRMED |
| D-18 | 2026-11-18 14:08 | A **rejected** version is never used as a comparison baseline. The candidate is compared **only** with the last **accepted** version currently in use — even if the rejected version has the same name as the last accepted one. | CONFIRMED |
| D-19 | 2026-11-18 14:14 | For the **duplicate-version semantic error**, only **accepted** version names count; a rejected version's name does not count as a previous version. | CONFIRMED |
| D-20 | 2026-11-18 14:14 | Notifications for **BLOCKED** and **WARNING** deployments must go to the concerned teams with complete information: detailed reason, related services, which API, which request/response line/field, and everything else related to the finding. | CONFIRMED |
| D-21 | 2026-11-18 14:14 | Frontend must display the **last accepted version** and provide **separate upload fields** for the consumer service YAML and the API spec YAML. Any errors must be reported back to the user. | CONFIRMED |

## 8. Open questions blocking implementation

- ~~**Q1:** Exact list of semantic errors~~ — RESOLVED by D-16: semantic error = duplicate version name only.
- **Q2:** Consumer-side upload: outcomes for adding/removing `reads`, adding extra `sends`, and changing path/method.
- **Q6:** Removal of a sunset-tagged element before/after its sunset date.
- ~~**Q7 (remaining part):** comparison baseline~~ — RESOLVED by D-15: last accepted version currently in use.
- **Q8 (remaining part):** Persistence choice — in-memory / JSON file / embedded database. Stack is fixed (D-17).
- **Q9:** Confirm or correct the inferences in §10 (I-2's baseline question is resolved by D-15; the rest remain open).
- **Q10:** Consumer-side outcomes for added/removed `reads`, extra `sends`, path/method change.
- ~~**Q11:** Does a rejected spec count as a previous version?~~ — RESOLVED by D-18 for the **diff baseline**: only the last accepted version is used.
- ~~**Q12:** Does a rejected version's name count for duplicate detection?~~ — RESOLVED by D-19: no; only accepted version names count.

## 9. Deliberately not assumed

Webhook payload/timing, UI layout details, metrics details, test framework, and file storage location are not decided yet.

## 10. Inferences from the chat (INFERRED — not yet confirmed)

These are readings of the product owner's messages, **not** rulings. Confirm or correct each one.

| ID | Inference | Why I inferred it |
|---|---|---|
| I-1 | "Versions go sequentially" means we follow the **order the files are supplied** (filename prefixes 1–4), not numeric sort of `info.version`. | This is the only reading that handles `claims-api` having two files both labelled `1.1.0` without inventing a new rule. |
| I-2 | Each version is judged on **its own changes**; a blocked predecessor does not taint its successor. | D-13 + D-15: judged against the last accepted version, so a blocked version never becomes the baseline. |
| I-3 | Notifications are deliberately **role-specific and minimal**: API owner only for breaking issues, service team only for unused changes, both teams only for additions. No broadcast to all teams. | You repeatedly corrected the recipient list and rejected "notify everyone" for extra fields. |
| I-4 | A consumer-side upload is a **request**, not just a data update: "the service team should first notify the api team and then only request it" implies a request/review workflow on the consumer side too. | Wording of your consumer-side rule. |
| I-5 | Severity is driven by **actual impact, not the label**: a "CRITICAL NOTICE" that breaks nothing is non-blocking; a change that breaks immediately is CRITICAL whatever it is called. | You said a critical notice blocks only "if it comes with an update and immediately breaks the services". |
| I-6 | The two upload fields mean **symmetric evaluation**: either side can be the proposer, and the other side is the contract baseline. | Your explicit frontend requirement. |
| I-7 | The broken `$ref`, duplicate version number and all renames in the kit are **deliberate test cases**, not data to be cleaned up. | Kit README says some versions contain problems to catch; you asked to test on the provided files. |
| I-8 | Later instructions always **override** earlier ones across the whole rule set, not only where you said "latest" explicitly. | You used "last prompt" / "latest ones" repeatedly; `DECISIONS.md` is maintained on that basis. |
