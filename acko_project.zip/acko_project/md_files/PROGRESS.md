# PROGRESS.md

## What works so far

- Spring Boot app starts with `mvn spring-boot:run` and with Docker Compose; UI on 8080, webhook receiver on 9900.
- H2 store, service/consumer registration, kit import and **Replay all spec versions**.
- YAML/JSON upload through UI and REST API; validation rejects invalid specs (broken `$ref` reported with the exact pointer).
- `$ref` resolution + effective-shape diff; classifier with CRITICAL/WARNING/NOTICE/INFO and correct recipients.
- Publish gate: CRITICAL → BLOCKED (never becomes baseline), otherwise ACCEPTED; every attempt recorded.
- Webhook notifications include outcome, baseline, full findings (severity, API, field/spec location, affected services, teams), errors and review id.
- All seven UI pages return 200; REST API returns metrics/history/diff/review queue.
- Diff page: choosing a service auto-loads its versions; from/to dropdowns now populated (using spec IDs, so duplicate version names can be distinguished) and rejected uploads are excluded. Verified a diff returns PARAMETER_RENAMED.
- Metrics page now explains every term, including the difference between a rejected upload (invalid file, never compared) and a blocked publish (valid file whose changes break consumers).
- `mvn test`: 5 unit tests pass (component rename, broken ref, field rename, sunset, consumer parsing).
- Verified kit replay (12 specs): 4 SAFE/ACCEPTED, 7 BLOCKED, 1 REJECTED; outcomes match the agreed rules (quote parameter rename and field rename block, policy sunset/removal block, claims broken ref rejected, claims requiredness change blocks).

## Rule corrections made during verification (change to plan)

- Enum-value **addition** is informational; removal is a WARNING because consumer files carry no enum values.
- `x-internal` operations are excluded from consumer-impact checks (unless a registered consumer uses them) — previous code flagged a new required internal query parameter as CRITICAL.
- A newly added **required request field** is CRITICAL when consumers don't send it (previously treated as NOTICE).
- Findings and validation errors are de-duplicated; review id is now attached before the notification is sent.

## Setup fix

- `docker-compose.yml` had been deleted and ignored; restored it and removed the ignore rule so
  `docker compose up --build` starts both the app and the webhook receiver again. README now
  documents Docker as the one-command option and Maven as the local alternative.
- Verified `docker compose config` and a full `docker compose up --build` with overridden ports.

## Next

- Copy AI transcripts into `transcripts/` before submission.
