# REVIEW.md — self review

## What works

Contract Guard registers the three providers and four consumers, imports the starter kit read-only, and replays all twelve spec versions in order. It resolves `$ref` and compares effective request/response shapes against the **last accepted** version, so a component rename alone does not produce a false alarm. Classified findings produce SAFE / WARN / BLOCKED, breaking publishes are stopped and never become the baseline, and every block or warning is sent to the webhook with the detailed reason, the API, the exact field and specification pointer, the affected services and the teams to notify. The UI has separate upload fields for API specs and consumer YAML, shows the last accepted version, reports upload errors inline, and offers diff, history, consumers and metrics views. Tests pass and the kit replay produces the outcomes we agreed with the product owner.

## What doesn't / limitations

- Review queue is a record only; there is no approve/override action (the product owner chose read-only).
- Consumer files do not record enum values or status codes, so enum removals and status-code removals can only be warnings.
- Webhook delivery is best-effort: failures are recorded in the payload but do not fail the publish.
- H2 is a single file database; no authentication or multi-user roles.
- AI-generated migration guides and a CI CLI gate are not built (listed as "going further").

## What the AI got wrong, and what I changed

- Initially compared component names / file organisation; fixed by resolving `$ref` into effective endpoint trees.
- Initially treated added enum values and internal-endpoint parameter changes as breaking; corrected to NOTICE/INFO after replay review.
- Initially missed a newly added required request field (`requestedBy`); now classified CRITICAL.
- Double-counted parameter renames and repeated identical findings; de-duplicated both.
- Notification was sent before the review id existed; now the id is attached first.
- Spring Boot 4 does not provide a Jackson 2 `ObjectMapper` bean; added an explicit bean.
- The Diff page's version dropdowns were empty because the service/version model attributes were missing; added them, auto-submit on service change, and switched version selection to spec IDs so two files sharing `1.1.0` are distinguishable.
- The Metrics page showed only numbers; added plain-language definitions, including rejected upload vs blocked publish.
- `docker-compose.yml` was deleted and ignored during a directory cleanup, breaking the one-command setup; restored it and removed the ignore rule.

## What I'd do next

Add a real approval workflow with reviewer identity, richer consumer usage declarations (enum values and expected status codes), a CI CLI check using the same classifier, and generated migration notes per affected team.
