package com.acko.contractguard.spec;

import com.acko.contractguard.diff.Differ;
import com.acko.contractguard.model.*;
import org.junit.jupiter.api.Test;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class SpecParserTest {

    private final SpecParser parser = new SpecParser();
    private final Differ differ = new Differ();

    private String spec(String service, String file) throws Exception {
        return Files.readString(Path.of("contract-guard-starter-kit/specs", service, file));
    }

    @Test
    void componentRenameIsNotReportedAsWireChange() throws Exception {
        ApiModel before = parser.toApiModel("quote-api", parser.read(spec("quote-api", "1-initial.yaml")));
        ApiModel after = parser.toApiModel("quote-api", parser.read(spec("quote-api", "2-reorganised.yaml")));
        List<Change> changes = differ.diff(before, after);
        assertTrue(changes.stream().noneMatch(c -> c.type() == ChangeType.FIELD_REMOVED
                && c.key().startsWith("premium")), "Premium fields must resolve through $ref renames");
        assertTrue(changes.stream().anyMatch(c -> c.type() == ChangeType.PARAMETER_RENAMED));
    }

    @Test
    void brokenRefIsRejected() throws Exception {
        var errors = parser.validate(parser.read(spec("claims-api", "2-channel-and-notes.yaml")));
        assertTrue(errors.stream().anyMatch(e -> e.contains("Unresolved $ref")), errors.toString());
    }

    @Test
    void fieldRenameIsDetected() throws Exception {
        ApiModel before = parser.toApiModel("quote-api", parser.read(spec("quote-api", "2-reorganised.yaml")));
        ApiModel after = parser.toApiModel("quote-api", parser.read(spec("quote-api", "3-price-lines.yaml")));
        List<Change> changes = differ.diff(before, after);
        assertTrue(changes.stream().anyMatch(c -> c.type() == ChangeType.FIELD_REMOVED
                && c.key().equals("premium.breakdown[].amount")));
        assertTrue(changes.stream().anyMatch(c -> c.type() == ChangeType.FIELD_ADDED
                && c.key().equals("premium.breakdown[].value")));
    }

    @Test
    void sunsetDatesAreDetected() throws Exception {
        ApiModel before = parser.toApiModel("policy-api", parser.read(spec("policy-api", "1-initial.yaml")));
        ApiModel after = parser.toApiModel("policy-api", parser.read(spec("policy-api", "2-deprecations.yaml")));
        List<Change> changes = differ.diff(before, after);
        assertTrue(changes.stream().anyMatch(c -> c.type() == ChangeType.SUNSET_DATE_SET_PAST
                && c.key().equals("legacyCode")));
        assertTrue(changes.stream().anyMatch(c -> c.type() == ChangeType.SUNSET_DATE_FUTURE
                && c.key().equals("holder.phone")));
    }

    @Test
    void consumerFileIsParsed() throws Exception {
        String content = Files.readString(Path.of("contract-guard-starter-kit/consumers/mobile-app.yaml"));
        ConsumerRegistration c = parser.parseConsumer(content);
        assertEquals("mobile-app", c.consumer());
        assertEquals(4, c.uses().size());
        assertTrue(c.uses().get(0).reads().contains("premium.breakdown[].amount"));
    }
}
