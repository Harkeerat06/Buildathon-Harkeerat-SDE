package com.acko.contractguard.diff;

import com.acko.contractguard.model.*;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.*;

@Component
public class Differ {

    public List<Change> diff(ApiModel previous, ApiModel candidate) {
        List<Change> changes = new ArrayList<>();
        Map<String, OperationModel> oldOps = index(previous);
        Map<String, OperationModel> newOps = index(candidate);

        for (OperationModel op : oldOps.values()) {
            if (!newOps.containsKey(op.key()) && !op.internal()) {
                changes.add(new Change(ChangeType.ENDPOINT_REMOVED, "Endpoint", op.key(), op.path(), null,
                        op.pointer(), op.internal()));
            }
        }
        for (OperationModel op : newOps.values()) {
            if (!oldOps.containsKey(op.key()) && !op.internal()) {
                changes.add(new Change(ChangeType.ENDPOINT_ADDED, "Endpoint", op.key(), null, op.path(),
                        op.pointer(), op.internal()));
            }
        }

        for (Map.Entry<String, OperationModel> entry : oldOps.entrySet()) {
            OperationModel newer = newOps.get(entry.getKey());
            if (newer == null) {
                continue;
            }
            OperationModel older = entry.getValue();
            changes.addAll(compareOperation(older, newer));
        }
        return changes;
    }

    private Map<String, OperationModel> index(ApiModel model) {
        Map<String, OperationModel> result = new LinkedHashMap<>();
        for (OperationModel op : model.operations()) {
            result.put(op.key(), op);
        }
        return result;
    }

    private List<Change> compareOperation(OperationModel older, OperationModel newer) {
        List<Change> changes = new ArrayList<>();
        String op = older.key();

        if (!older.pathParamNames().equals(newer.pathParamNames())
                && older.pathParamNames().size() == newer.pathParamNames().size()) {
            for (int i = 0; i < older.pathParamNames().size(); i++) {
                String before = older.pathParamNames().get(i);
                String after = newer.pathParamNames().get(i);
                if (!before.equals(after)) {
                    changes.add(new Change(ChangeType.PARAMETER_RENAMED, "Request", before, before, after,
                            newer.pointer(), newer.internal()));
                }
            }
        }

        Map<String, ParamInfo> oldParams = new LinkedHashMap<>();
        older.parameters().forEach(p -> oldParams.put(p.in() + ":" + p.name(), p));
        for (ParamInfo p : newer.parameters()) {
            ParamInfo old = oldParams.get(p.in() + ":" + p.name());
            if (old == null) {
                if ("path".equals(p.in())) {
                    continue; // path-parameter changes are reported as renames
                }
                changes.add(new Change(ChangeType.PARAMETER_ADDED, "Request", p.name(),
                        p.required() ? "required" : "optional", null, p.pointer(), newer.internal()));
            } else if (old.required() != p.required() && !"path".equals(p.in())) {
                changes.add(new Change(ChangeType.PARAMETER_ADDED, "Request", p.name(),
                        old.required() ? "required" : "optional", p.required() ? "required" : "optional",
                        p.pointer(), newer.internal()));
            }
        }

        changes.addAll(diffFields(older.requestFields(), newer.requestFields(), "Request",
                newer.pointer(), newer.internal()));

        for (Map.Entry<String, Map<String, FieldInfo>> resp : older.responses().entrySet()) {
            Map<String, FieldInfo> newerFields = newer.responses().get(resp.getKey());
            if (newerFields == null) {
                changes.add(new Change(ChangeType.STATUS_CODE_REMOVED, "Response", resp.getKey(),
                        resp.getKey(), null, newer.pointer(), newer.internal()));
            } else {
                changes.addAll(diffFields(resp.getValue(), newerFields, "Response " + resp.getKey(),
                        newer.pointer(), newer.internal()));
            }
        }
        for (String code : newer.responses().keySet()) {
            if (!older.responses().containsKey(code)) {
                changes.add(new Change(ChangeType.STATUS_CODE_ADDED, "Response", code, null, code,
                        newer.pointer(), newer.internal()));
            }
        }
        return changes;
    }

    private List<Change> diffFields(Map<String, FieldInfo> older, Map<String, FieldInfo> newer,
                                    String side, String pointer, boolean internal) {
        List<Change> changes = new ArrayList<>();
        for (Map.Entry<String, FieldInfo> e : older.entrySet()) {
            FieldInfo after = newer.get(e.getKey());
            FieldInfo before = e.getValue();
            if (after == null) {
                ChangeType type = ChangeType.FIELD_REMOVED;
                if (before.sunset() != null) {
                    type = isPast(before.sunset())
                            ? ChangeType.ELEMENT_REMOVED_AFTER_SUNSET
                            : ChangeType.ELEMENT_REMOVED_BEFORE_SUNSET;
                }
                changes.add(new Change(type, side, e.getKey(), before.type(), null,
                        before.pointer(), internal));
            }
        }
        for (Map.Entry<String, FieldInfo> e : newer.entrySet()) {
            FieldInfo before = older.get(e.getKey());
            FieldInfo after = e.getValue();
            if (before == null) {
                changes.add(new Change(ChangeType.FIELD_ADDED, side, e.getKey(), null,
                        after.type() + (after.required() ? " (required)" : ""), after.pointer(), internal));
                if (after.sunset() != null) {
                    changes.add(new Change(isPast(after.sunset())
                                    ? ChangeType.SUNSET_DATE_SET_PAST : ChangeType.SUNSET_DATE_FUTURE,
                            side, e.getKey(), null, after.sunset(), after.pointer(), internal));
                }
                continue;
            }
            if (!Objects.equals(before.type(), after.type())) {
                changes.add(new Change(ChangeType.FIELD_TYPE_CHANGED, side, e.getKey(),
                        before.type(), after.type(), after.pointer(), internal));
            }
            if (before.required() != after.required()) {
                changes.add(new Change(ChangeType.FIELD_REQUIRED_CHANGED, side, e.getKey(),
                        String.valueOf(before.required()), String.valueOf(after.required()),
                        after.pointer(), internal));
            }
            if (!Objects.equals(before.enumValues(), after.enumValues())) {
                changes.add(new Change(ChangeType.FIELD_ENUM_CHANGED, side, e.getKey(),
                        String.valueOf(before.enumValues()), String.valueOf(after.enumValues()),
                        after.pointer(), internal));
            }
            if (!Objects.equals(before.minimum(), after.minimum())
                    || !Objects.equals(before.maximum(), after.maximum())) {
                changes.add(new Change(ChangeType.FIELD_CONSTRAINT_CHANGED, side, e.getKey(),
                        before.minimum() + ".." + before.maximum(), after.minimum() + ".." + after.maximum(),
                        after.pointer(), internal));
            }
            if (after.sunset() != null && !Objects.equals(before.sunset(), after.sunset())) {
                changes.add(new Change(isPast(after.sunset())
                                ? ChangeType.SUNSET_DATE_SET_PAST : ChangeType.SUNSET_DATE_FUTURE,
                        side, e.getKey(), before.sunset(), after.sunset(), after.pointer(), internal));
            }
        }
        return changes;
    }

    public boolean isPast(String date) {
        try {
            return LocalDate.parse(date).isBefore(LocalDate.now());
        } catch (Exception e) {
            return false;
        }
    }
}
