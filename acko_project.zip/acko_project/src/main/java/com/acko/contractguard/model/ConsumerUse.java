package com.acko.contractguard.model;

import java.util.List;

public record ConsumerUse(String provider, String method, String path,
                          List<String> sends, List<String> reads) {
}
