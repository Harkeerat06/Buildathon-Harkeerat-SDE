package com.acko.contractguard.model;

import java.time.Instant;

public record SpecVersion(
        long id,
        String service,
        String version,
        String fileName,
        String rawYaml,
        SpecStatus status,
        Instant uploadedAt
) {
}
