package com.acko.contractguard.model;

import java.time.Instant;

public record Attempt(
        long id,
        String service,
        String version,
        Outcome outcome,
        String summary,
        String findingsJson,
        Instant createdAt
) {
}
