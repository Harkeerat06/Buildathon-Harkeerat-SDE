package com.acko.contractguard.model;

public record ParamInfo(String name, String in, boolean required, String pointer) {
}
