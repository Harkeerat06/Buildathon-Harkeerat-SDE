package com.acko.contractguard.model;

public record Change(
        ChangeType type,
        String side,
        String key,
        String oldValue,
        String newValue,
        String pointer,
        boolean internal
) {
    public String describe() {
        return switch (type) {
            case ENDPOINT_REMOVED -> "Endpoint " + key + " was removed";
            case ENDPOINT_ADDED -> "Endpoint " + key + " was added";
            case PARAMETER_RENAMED -> "Parameter renamed from '" + oldValue + "' to '" + newValue + "' on " + key;
            case PARAMETER_ADDED -> "Parameter '" + key + "' was added as " + oldValue;
            case FIELD_REMOVED -> side.toLowerCase() + " field '" + key + "' was removed";
            case FIELD_ADDED -> side.toLowerCase() + " field '" + key + "' was added";
            case FIELD_TYPE_CHANGED -> side.toLowerCase() + " field '" + key + "' changed type from " + oldValue + " to " + newValue;
            case FIELD_REQUIRED_CHANGED -> side.toLowerCase() + " field '" + key + "' changed requiredness from " + oldValue + " to " + newValue;
            case FIELD_ENUM_CHANGED -> side.toLowerCase() + " field '" + key + "' allowed values changed from " + oldValue + " to " + newValue;
            case FIELD_CONSTRAINT_CHANGED -> side.toLowerCase() + " field '" + key + "' constraints changed from " + oldValue + " to " + newValue;
            case STATUS_CODE_REMOVED -> "Response status code " + key + " was removed";
            case STATUS_CODE_ADDED -> "Response status code " + key + " was added";
            case SUNSET_DATE_PAST -> "Field '" + key + "' has a sunset date in the past (" + newValue + ")";
            case SUNSET_DATE_FUTURE -> "Field '" + key + "' is marked for sunset on " + newValue;
            case SUNSET_DATE_SET_PAST -> "New version sets a past sunset date (" + newValue + ") for '" + key + "'";
            case ELEMENT_REMOVED_AFTER_SUNSET -> "Field '" + key + "' was removed after its sunset date";
            case ELEMENT_REMOVED_BEFORE_SUNSET -> "Field '" + key + "' was removed before its sunset date";
            case DUPLICATE_VERSION -> "Version name '" + key + "' has already been accepted";
            case INVALID_SPEC -> "Invalid specification: " + key;
        };
    }
}
