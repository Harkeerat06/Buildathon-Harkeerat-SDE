package com.acko.contractguard.model;

import java.util.List;

public record Decision(
        Outcome outcome,
        String service,
        String version,
        String baselineVersion,
        List<Finding> findings,
        List<String> errors,
        Long reviewId,
        String summary
) {
    public boolean isBlocked() {
        return outcome == Outcome.BLOCKED;
    }
}
