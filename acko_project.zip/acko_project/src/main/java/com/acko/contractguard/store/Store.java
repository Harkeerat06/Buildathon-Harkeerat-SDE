package com.acko.contractguard.store;

import com.acko.contractguard.model.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;

@Repository
public class Store {

    private final JdbcTemplate jdbc;
    private final ObjectMapper mapper;

    public Store(JdbcTemplate jdbc, ObjectMapper mapper) {
        this.jdbc = jdbc;
        this.mapper = mapper;
    }

    @PostConstruct
    public void init() {
        jdbc.execute("CREATE TABLE IF NOT EXISTS services (id BIGINT AUTO_INCREMENT PRIMARY KEY, "
                + "name VARCHAR(120) UNIQUE, kind VARCHAR(20), owner_team VARCHAR(120))");
        jdbc.execute("CREATE TABLE IF NOT EXISTS specs (id BIGINT AUTO_INCREMENT PRIMARY KEY, "
                + "service VARCHAR(120), version VARCHAR(60), file_name VARCHAR(255), raw_yaml CLOB, "
                + "status VARCHAR(20), uploaded_at TIMESTAMP)");
        jdbc.execute("CREATE TABLE IF NOT EXISTS consumers (id BIGINT AUTO_INCREMENT PRIMARY KEY, "
                + "name VARCHAR(120) UNIQUE, team VARCHAR(120), uses_json CLOB)");
        jdbc.execute("CREATE TABLE IF NOT EXISTS attempts (id BIGINT AUTO_INCREMENT PRIMARY KEY, "
                + "service VARCHAR(120), version VARCHAR(60), outcome VARCHAR(20), summary CLOB, "
                + "findings_json CLOB, created_at TIMESTAMP)");
        jdbc.execute("CREATE TABLE IF NOT EXISTS notifications (id BIGINT AUTO_INCREMENT PRIMARY KEY, "
                + "attempt_id BIGINT, payload CLOB, sent_at TIMESTAMP)");
    }

    public void registerService(String name, ServiceKind kind, String ownerTeam) {
        jdbc.update("MERGE INTO services (name, kind, owner_team) KEY(name) VALUES (?,?,?)",
                name, kind.name(), ownerTeam);
    }

    public List<ServiceRegistration> listServices() {
        return jdbc.query("SELECT id, name, kind, owner_team FROM services ORDER BY kind, name",
                (rs, n) -> new ServiceRegistration(rs.getLong("id"), rs.getString("name"),
                        ServiceKind.valueOf(rs.getString("kind")), rs.getString("owner_team")));
    }

    public String ownerOf(String name) {
        List<String> result = jdbc.query("SELECT owner_team FROM services WHERE name = ?",
                (rs, n) -> rs.getString(1), name);
        return result.isEmpty() ? name : result.get(0);
    }

    public void registerConsumer(String name, String team, List<ConsumerUse> uses) {
        try {
            jdbc.update("MERGE INTO consumers (name, team, uses_json) KEY(name) VALUES (?,?,?)",
                    name, team, mapper.writeValueAsString(uses));
        } catch (JsonProcessingException e) {
            throw new IllegalStateException("Cannot store consumer usages", e);
        }
    }

    public ConsumerRegistration getConsumer(String name) {
        List<ConsumerRegistration> result = jdbc.query(
                "SELECT name, team, uses_json FROM consumers WHERE name = ?", (rs, n) -> {
                    try {
                        List<ConsumerUse> uses = mapper.readValue(rs.getString("uses_json"),
                                mapper.getTypeFactory().constructCollectionType(List.class, ConsumerUse.class));
                        return new ConsumerRegistration(rs.getString("name"), rs.getString("team"), uses);
                    } catch (JsonProcessingException e) {
                        throw new IllegalStateException("Cannot read consumer usages", e);
                    }
                }, name);
        return result.isEmpty() ? null : result.get(0);
    }

    public List<ConsumerRegistration> listConsumers() {
        return jdbc.query("SELECT name, team, uses_json FROM consumers ORDER BY name", (rs, n) -> {
            try {
                List<ConsumerUse> uses = mapper.readValue(rs.getString("uses_json"),
                        mapper.getTypeFactory().constructCollectionType(List.class, ConsumerUse.class));
                return new ConsumerRegistration(rs.getString("name"), rs.getString("team"), uses);
            } catch (JsonProcessingException e) {
                throw new IllegalStateException("Cannot read consumer usages", e);
            }
        });
    }

    public SpecVersion saveSpec(String service, String version, String fileName, String rawYaml, SpecStatus status) {
        jdbc.update("INSERT INTO specs (service, version, file_name, raw_yaml, status, uploaded_at) "
                        + "VALUES (?,?,?,?,?,?)", service, version, fileName, rawYaml, status.name(), Instant.now());
        long id = jdbc.queryForObject("SELECT MAX(id) FROM specs", Long.class);
        return new SpecVersion(id, service, version, fileName, rawYaml, status, Instant.now());
    }

    public SpecVersion lastAccepted(String service) {
        List<SpecVersion> result = jdbc.query(
                "SELECT id, service, version, file_name, raw_yaml, status, uploaded_at FROM specs "
                        + "WHERE service = ? AND status = 'ACCEPTED' ORDER BY id DESC LIMIT 1", this::mapSpec, service);
        return result.isEmpty() ? null : result.get(0);
    }

    public boolean hasAcceptedVersion(String service, String version) {
        Integer count = jdbc.queryForObject(
                "SELECT COUNT(*) FROM specs WHERE service = ? AND version = ? AND status = 'ACCEPTED'",
                Integer.class, service, version);
        return count != null && count > 0;
    }

    public List<SpecVersion> listSpecs(String service) {
        if (service == null || service.isBlank()) {
            return jdbc.query("SELECT id, service, version, file_name, raw_yaml, status, uploaded_at "
                    + "FROM specs ORDER BY id", this::mapSpec);
        }
        return jdbc.query("SELECT id, service, version, file_name, raw_yaml, status, uploaded_at "
                + "FROM specs WHERE service = ? ORDER BY id", this::mapSpec, service);
    }

    private SpecVersion mapSpec(java.sql.ResultSet rs, int n) throws java.sql.SQLException {
        return new SpecVersion(rs.getLong("id"), rs.getString("service"), rs.getString("version"),
                rs.getString("file_name"), rs.getString("raw_yaml"),
                SpecStatus.valueOf(rs.getString("status")), rs.getTimestamp("uploaded_at").toInstant());
    }

    public Attempt saveAttempt(String service, String version, Decision decision) {
        String json;
        try {
            json = mapper.writeValueAsString(decision.findings());
        } catch (JsonProcessingException e) {
            json = "[]";
        }
        jdbc.update("INSERT INTO attempts (service, version, outcome, summary, findings_json, created_at) "
                        + "VALUES (?,?,?,?,?,?)", service, version, decision.outcome().name(),
                decision.summary(), json, Instant.now());
        long id = jdbc.queryForObject("SELECT MAX(id) FROM attempts", Long.class);
        return new Attempt(id, service, version, decision.outcome(), decision.summary(), json, Instant.now());
    }

    public List<Attempt> listAttempts() {
        return jdbc.query("SELECT id, service, version, outcome, summary, findings_json, created_at "
                        + "FROM attempts ORDER BY id DESC",
                (rs, n) -> new Attempt(rs.getLong("id"), rs.getString("service"), rs.getString("version"),
                        Outcome.valueOf(rs.getString("outcome")), rs.getString("summary"),
                        rs.getString("findings_json"), rs.getTimestamp("created_at").toInstant()));
    }

    public void saveNotification(long attemptId, String payload) {
        jdbc.update("INSERT INTO notifications (attempt_id, payload, sent_at) VALUES (?,?,?)",
                attemptId, payload, Instant.now());
    }

    public List<String> listNotifications() {
        return jdbc.query("SELECT payload FROM notifications ORDER BY id DESC", (rs, n) -> rs.getString(1));
    }

    public long count(String sql, Object... args) {
        Long value = jdbc.queryForObject(sql, Long.class, args);
        return value == null ? 0 : value;
    }
}
