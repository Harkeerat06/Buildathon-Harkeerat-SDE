package com.acko.contractguard.model;

public enum SpecStatus {
    ACCEPTED, BLOCKED, REJECTED
}
