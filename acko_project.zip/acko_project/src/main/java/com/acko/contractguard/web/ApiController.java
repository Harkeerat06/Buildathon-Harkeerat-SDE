package com.acko.contractguard.web;

import com.acko.contractguard.diff.Differ;
import com.acko.contractguard.model.*;
import com.acko.contractguard.publish.PublishService;
import com.acko.contractguard.spec.SpecParser;
import com.acko.contractguard.store.Store;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.*;

@RestController
@RequestMapping("/api")
public class ApiController {

    private final Store store;
    private final PublishService publishService;
    private final SpecParser parser;
    private final Differ differ;

    public ApiController(Store store, PublishService publishService, SpecParser parser, Differ differ) {
        this.store = store;
        this.publishService = publishService;
        this.parser = parser;
        this.differ = differ;
    }

    @PostMapping("/services")
    public Map<String, Object> registerService(@RequestParam String name,
                                               @RequestParam String kind,
                                               @RequestParam(defaultValue = "") String team) {
        store.registerService(name, ServiceKind.valueOf(kind.toUpperCase(Locale.ROOT)), team);
        return Map.of("ok", true, "name", name);
    }

    @PostMapping("/specs/upload")
    public Decision uploadSpec(@RequestParam String service, @RequestParam("file") MultipartFile file)
            throws Exception {
        return publishService.publishProvider(service, file.getOriginalFilename(), file.getOriginalFilename(),
                new String(file.getBytes()));
    }

    @PostMapping("/consumers/upload")
    public Decision uploadConsumer(@RequestParam(defaultValue = "") String team,
                                   @RequestParam("file") MultipartFile file) throws Exception {
        return publishService.publishConsumer(team, team, new String(file.getBytes()));
    }

    @GetMapping("/specs/{service}/versions")
    public List<SpecVersion> versions(@PathVariable String service) {
        return store.listSpecs(service);
    }

    @GetMapping("/specs/{service}/diff")
    public ResponseEntity<?> diff(@PathVariable String service,
                                  @RequestParam String from, @RequestParam String to) {
        SpecVersion a = find(service, from);
        SpecVersion b = find(service, to);
        if (a == null || b == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "Unknown version pair"));
        }
        try {
            ApiModel before = parser.toApiModel(service, parser.read(a.rawYaml()));
            ApiModel after = parser.toApiModel(service, parser.read(b.rawYaml()));
            return ResponseEntity.ok(differ.diff(before, after));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/history")
    public List<Attempt> history() {
        return store.listAttempts();
    }

    @GetMapping("/review-queue")
    public List<Attempt> reviewQueue() {
        return store.listAttempts().stream().filter(a -> a.outcome() == Outcome.BLOCKED).toList();
    }

    @GetMapping("/consumers")
    public List<ConsumerRegistration> consumers() {
        return store.listConsumers();
    }

    @GetMapping("/metrics")
    public Map<String, Object> metrics() {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("providers", store.count("SELECT COUNT(*) FROM services WHERE kind='PROVIDER'"));
        result.put("consumers", store.count("SELECT COUNT(*) FROM services WHERE kind='CONSUMER'"));
        result.put("accepted", store.count("SELECT COUNT(*) FROM specs WHERE status='ACCEPTED'"));
        result.put("blocked", store.count("SELECT COUNT(*) FROM specs WHERE status='BLOCKED'"));
        result.put("rejected", store.count("SELECT COUNT(*) FROM specs WHERE status='REJECTED'"));
        result.put("dangerousCaught", store.count("SELECT COUNT(*) FROM attempts WHERE outcome='BLOCKED'"));
        result.put("warnings", store.count("SELECT COUNT(*) FROM attempts WHERE outcome='WARN'"));
        result.put("safe", store.count("SELECT COUNT(*) FROM attempts WHERE outcome='SAFE'"));
        result.put("notifications", store.count("SELECT COUNT(*) FROM notifications"));
        return result;
    }

    private SpecVersion find(String service, String version) {
        return store.listSpecs(service).stream()
                .filter(s -> s.version().equals(version)).findFirst().orElse(null);
    }
}
