package com.acko.contractguard.model;

import java.util.List;

public record FieldInfo(
        String type,
        boolean required,
        List<String> enumValues,
        Number minimum,
        Number maximum,
        boolean deprecated,
        String sunset,
        String pointer
) {
    public static FieldInfo simple(String type, boolean required, String pointer) {
        return new FieldInfo(type, required, List.of(), null, null, false, null, pointer);
    }
}
