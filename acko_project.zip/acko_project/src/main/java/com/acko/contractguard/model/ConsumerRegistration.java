package com.acko.contractguard.model;

import java.util.List;

public record ConsumerRegistration(String consumer, String team, List<ConsumerUse> uses) {
}
