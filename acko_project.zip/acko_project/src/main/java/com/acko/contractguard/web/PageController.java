package com.acko.contractguard.web;

import com.acko.contractguard.diff.Differ;
import com.acko.contractguard.model.*;
import com.acko.contractguard.publish.PublishService;
import com.acko.contractguard.spec.SpecParser;
import com.acko.contractguard.store.Store;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;

@Controller
public class PageController {

    private final Store store;
    private final PublishService publishService;
    private final SpecParser parser;
    private final Differ differ;
    private final String kitPath;

    public PageController(Store store, PublishService publishService, SpecParser parser, Differ differ,
                          @Value("${app.kit.path}") String kitPath) {
        this.store = store;
        this.publishService = publishService;
        this.parser = parser;
        this.differ = differ;
        this.kitPath = kitPath;
    }

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("services", store.listServices());
        model.addAttribute("specs", store.listSpecs(null));
        model.addAttribute("attempts", store.listAttempts());
        model.addAttribute("accepted", store.count("SELECT COUNT(*) FROM specs WHERE status='ACCEPTED'"));
        model.addAttribute("blocked", store.count("SELECT COUNT(*) FROM specs WHERE status='BLOCKED'"));
        model.addAttribute("rejected", store.count("SELECT COUNT(*) FROM specs WHERE status='REJECTED'"));
        model.addAttribute("consumers", store.listConsumers().size());
        return "home";
    }

    @GetMapping("/upload-spec")
    public String uploadSpecForm(Model model) {
        model.addAttribute("providers", store.listServices().stream()
                .filter(s -> s.kind() == ServiceKind.PROVIDER).toList());
        model.addAttribute("acceptedByService", acceptedByService());
        return "upload-spec";
    }

    @PostMapping("/upload-spec")
    public String uploadSpec(@RequestParam String service, @RequestParam("file") MultipartFile file, Model model) {
        try {
            Decision decision = publishService.publishProvider(service, file.getOriginalFilename(),
                    file.getOriginalFilename(), new String(file.getBytes()));
            model.addAttribute("decision", decision);
        } catch (Exception e) {
            model.addAttribute("error", "Upload failed: " + e.getMessage());
        }
        model.addAttribute("providers", store.listServices().stream()
                .filter(s -> s.kind() == ServiceKind.PROVIDER).toList());
        model.addAttribute("acceptedByService", acceptedByService());
        return "upload-spec";
    }

    @GetMapping("/upload-consumer")
    public String uploadConsumerForm(Model model) {
        model.addAttribute("consumers", store.listConsumers());
        return "upload-consumer";
    }

    @PostMapping("/upload-consumer")
    public String uploadConsumer(@RequestParam(defaultValue = "") String team,
                                 @RequestParam("file") MultipartFile file, Model model) {
        try {
            model.addAttribute("decision", publishService.publishConsumer(team, team, new String(file.getBytes())));
        } catch (Exception e) {
            model.addAttribute("error", "Upload failed: " + e.getMessage());
        }
        model.addAttribute("consumers", store.listConsumers());
        return "upload-consumer";
    }

    @GetMapping("/diff")
    public String diffForm(@RequestParam(required = false) String service,
                           @RequestParam(required = false) String from,
                           @RequestParam(required = false) String to, Model model) {
        model.addAttribute("providers", store.listServices().stream()
                .filter(s -> s.kind() == ServiceKind.PROVIDER).toList());
        model.addAttribute("versions", service == null ? List.of() : store.listSpecs(service).stream()
                .filter(v -> v.status() != SpecStatus.REJECTED).toList());
        model.addAttribute("service", service);
        model.addAttribute("from", from);
        model.addAttribute("to", to);
        model.addAttribute("changes", List.of());
        if (service != null && from != null && to != null) {
            SpecVersion a = findById(service, from);
            SpecVersion b = findById(service, to);
            if (a != null && b != null) {
                try {
                    model.addAttribute("changes", differ.diff(
                            parser.toApiModel(service, parser.read(a.rawYaml())),
                            parser.toApiModel(service, parser.read(b.rawYaml()))));
                } catch (Exception e) {
                    model.addAttribute("error", e.getMessage());
                }
            } else {
                model.addAttribute("error", "One of the selected versions is no longer available.");
            }
        }
        return "diff";
    }

    @GetMapping("/history")
    public String history(Model model) {
        model.addAttribute("attempts", store.listAttempts());
        model.addAttribute("notifications", store.listNotifications());
        return "history";
    }

    @GetMapping("/consumers")
    public String consumers(Model model) {
        model.addAttribute("consumers", store.listConsumers());
        return "consumers";
    }

    @GetMapping("/metrics")
    public String metrics(Model model) {
        model.addAttribute("metrics", Map.of(
                "Providers", store.count("SELECT COUNT(*) FROM services WHERE kind='PROVIDER'"),
                "Consumers registered", store.count("SELECT COUNT(*) FROM services WHERE kind='CONSUMER'"),
                "Accepted versions", store.count("SELECT COUNT(*) FROM specs WHERE status='ACCEPTED'"),
                "Blocked publishes", store.count("SELECT COUNT(*) FROM attempts WHERE outcome='BLOCKED'"),
                "Warned publishes", store.count("SELECT COUNT(*) FROM attempts WHERE outcome='WARN'"),
                "Safe publishes", store.count("SELECT COUNT(*) FROM attempts WHERE outcome='SAFE'"),
                "Rejected uploads", store.count("SELECT COUNT(*) FROM specs WHERE status='REJECTED'"),
                "Notifications sent", store.count("SELECT COUNT(*) FROM notifications")));
        return "metrics";
    }

    @PostMapping("/import-kit")
    public String importKit(RedirectAttributes redirect) {
        try {
            Path root = Paths.get(kitPath);
            for (String provider : List.of("quote-api", "policy-api", "claims-api")) {
                Path dir = root.resolve("specs").resolve(provider);
                if (!Files.isDirectory(dir)) {
                    continue;
                }
                String owner = ownerOf(dir);
                store.registerService(provider, ServiceKind.PROVIDER, owner);
            }
            Path consumersDir = root.resolve("consumers");
            if (Files.isDirectory(consumersDir)) {
                try (var files = Files.list(consumersDir)) {
                    for (Path file : files.filter(p -> p.toString().endsWith(".yaml")).sorted().toList()) {
                        ConsumerRegistration c = parser.parseConsumer(Files.readString(file));
                        store.registerConsumer(c.consumer(), c.team(), c.uses());
                        store.registerService(c.consumer(), ServiceKind.CONSUMER, c.team());
                    }
                }
            }
            redirect.addFlashAttribute("message", "Starter kit services and consumers imported.");
        } catch (Exception e) {
            redirect.addFlashAttribute("error", "Import failed: " + e.getMessage());
        }
        return "redirect:/";
    }

    @PostMapping("/replay-kit")
    public String replayKit(RedirectAttributes redirect) {
        int blocked = 0;
        int accepted = 0;
        int rejected = 0;
        try {
            Path root = Paths.get(kitPath);
            for (String provider : List.of("quote-api", "policy-api", "claims-api")) {
                Path dir = root.resolve("specs").resolve(provider);
                if (!Files.isDirectory(dir)) {
                    continue;
                }
                store.registerService(provider, ServiceKind.PROVIDER, ownerOf(dir));
                List<Path> files;
                try (var stream = Files.list(dir)) {
                    files = stream.filter(p -> p.toString().endsWith(".yaml")).sorted().toList();
                }
                for (Path file : files) {
                    JsonNode node = parser.read(Files.readString(file));
                    String version = node.path("info").path("version").asText("unknown");
                    Decision d = publishService.publishProvider(provider, version, file.getFileName().toString(),
                            Files.readString(file));
                    if (d.outcome() == Outcome.BLOCKED) blocked++;
                    else if (d.outcome() == Outcome.REJECTED) rejected++;
                    else accepted++;
                }
            }
            redirect.addFlashAttribute("message", "Replay finished: " + accepted + " accepted, "
                    + blocked + " blocked, " + rejected + " rejected.");
        } catch (Exception e) {
            redirect.addFlashAttribute("error", "Replay failed: " + e.getMessage());
        }
        return "redirect:/history";
    }

    private String ownerOf(Path dir) throws IOException {
        try (var files = Files.list(dir)) {
            for (Path file : files.filter(p -> p.toString().endsWith(".yaml")).sorted().toList()) {
                String text = Files.readString(file);
                var m = java.util.regex.Pattern.compile("Owner:\\s*([^.']+)").matcher(text);
                if (m.find()) {
                    return m.group(1).trim();
                }
            }
        }
        return "API team";
    }

    private Map<String, String> acceptedByService() {
        Map<String, String> result = new LinkedHashMap<>();
        for (ServiceRegistration s : store.listServices()) {
            if (s.kind() == ServiceKind.PROVIDER) {
                SpecVersion last = store.lastAccepted(s.name());
                result.put(s.name(), last == null ? "none yet" : last.version() + " (" + last.fileName() + ")");
            }
        }
        return result;
    }

    private SpecVersion find(String service, String version) {
        return store.listSpecs(service).stream().filter(s -> s.version().equals(version)).findFirst().orElse(null);
    }

    private SpecVersion findById(String service, String id) {
        return store.listSpecs(service).stream()
                .filter(s -> String.valueOf(s.id()).equals(id)).findFirst().orElse(null);
    }
}
