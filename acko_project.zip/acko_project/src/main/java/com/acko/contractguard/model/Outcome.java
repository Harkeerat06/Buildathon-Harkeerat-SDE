package com.acko.contractguard.model;

public enum Outcome {
    SAFE, WARN, BLOCKED, REJECTED
}
