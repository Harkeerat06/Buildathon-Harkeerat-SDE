package com.acko.contractguard.model;

import java.util.List;
import java.util.Map;

public record OperationModel(
        String method,
        String path,
        String normalizedPath,
        List<String> pathParamNames,
        List<ParamInfo> parameters,
        Map<String, FieldInfo> requestFields,
        Map<String, Map<String, FieldInfo>> responses,
        boolean internal,
        String sunset,
        String pointer
) {
    public String key() {
        return method + " " + normalizedPath;
    }
}
