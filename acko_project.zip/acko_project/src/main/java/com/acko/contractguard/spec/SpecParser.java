package com.acko.contractguard.spec;

import com.acko.contractguard.model.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class SpecParser {

    private final ObjectMapper yaml = new ObjectMapper(new YAMLFactory());

    public JsonNode read(String content) throws Exception {
        return yaml.readTree(content);
    }

    public List<String> validate(JsonNode root) {
        Set<String> errors = new LinkedHashSet<>();
        if (root == null || !root.isObject()) {
            errors.add("The file is not a YAML/JSON object");
            return new ArrayList<>(errors);
        }
        String openapi = root.path("openapi").asText("");
        if (!openapi.startsWith("3.")) {
            errors.add("Missing or unsupported 'openapi' version (expected 3.x)");
        }
        String version = root.path("info").path("version").asText("");
        if (version.isBlank()) {
            errors.add("Missing info.version");
        }
        if (!root.path("paths").isObject()) {
            errors.add("Missing 'paths' object");
        }
        checkRefs(root, root, errors, "#", new HashSet<>(), 0);
        return new ArrayList<>(errors);
    }

    private void checkRefs(JsonNode node, JsonNode root, Set<String> errors, String pointer,
                           Set<String> visiting, int depth) {
        if (depth > 30 || node == null) {
            return;
        }
        if (node.isObject()) {
            JsonNode ref = node.get("$ref");
            if (ref != null && ref.isTextual()) {
                String refText = ref.asText();
                JsonNode target = pointer(refText, root);
                if (target == null) {
                    errors.add("Unresolved $ref '" + refText + "' at " + pointer);
                } else if (!visiting.add(refText)) {
                    errors.add("Circular $ref '" + refText + "' at " + pointer);
                } else {
                    checkRefs(target, root, errors, refText, visiting, depth + 1);
                    visiting.remove(refText);
                }
            }
            node.fields().forEachRemaining(e -> checkRefs(e.getValue(), root, errors,
                    pointer + "/" + escape(e.getKey()), visiting, depth + 1));
        } else if (node.isArray()) {
            int i = 0;
            for (JsonNode child : node) {
                checkRefs(child, root, errors, pointer + "/" + i++, visiting, depth + 1);
            }
        }
    }

    private JsonNode pointer(String ref, JsonNode root) {
        if (!ref.startsWith("#/")) {
            return null;
        }
        JsonNode current = root;
        for (String raw : ref.substring(2).split("/")) {
            String key = raw.replace("~1", "/").replace("~0", "~");
            if (current == null || !current.isObject()) {
                return null;
            }
            current = current.get(key);
        }
        return current;
    }

    public ApiModel toApiModel(String service, JsonNode root) {
        String version = root.path("info").path("version").asText("");
        List<OperationModel> operations = new ArrayList<>();
        JsonNode paths = root.path("paths");
        paths.fields().forEachRemaining(pathEntry -> {
            String path = pathEntry.getKey();
            JsonNode pathItem = pathEntry.getValue();
            if (!pathItem.isObject()) {
                return;
            }
            pathItem.fields().forEachRemaining(methodEntry -> {
                String method = methodEntry.getKey().toLowerCase(Locale.ROOT);
                if (!Set.of("get", "post", "put", "delete", "patch", "head", "options").contains(method)) {
                    return;
                }
                JsonNode op = methodEntry.getValue();
                if (!op.isObject()) {
                    return;
                }
                String pointer = "#/paths/" + escape(path) + "/" + method;
                JsonNode resolved = resolve(op, root, new HashSet<>(), 0);

                String normalized = path.replaceAll("\\{[^}]+\\}", "{}");
                List<String> pathParams = new ArrayList<>();
                java.util.regex.Matcher matcher = java.util.regex.Pattern.compile("\\{([^}]+)\\}").matcher(path);
                while (matcher.find()) {
                    pathParams.add(matcher.group(1));
                }

                List<ParamInfo> params = new ArrayList<>();
                JsonNode paramsNode = resolved.path("parameters");
                if (paramsNode.isArray()) {
                    int i = 0;
                    for (JsonNode p : paramsNode) {
                        params.add(new ParamInfo(p.path("name").asText(""), p.path("in").asText(""),
                                p.path("required").asBoolean(false), pointer + "/parameters/" + i++));
                    }
                }

                Map<String, FieldInfo> requestFields = new LinkedHashMap<>();
                JsonNode bodySchema = resolved.path("requestBody").path("content")
                        .path("application/json").path("schema");
                if (!bodySchema.isMissingNode()) {
                    flatten(bodySchema, root, "", false, requestFields,
                            pointer + "/requestBody/content/application~1json/schema", new HashSet<>(), 0);
                }
                for (ParamInfo p : params) {
                    if (!"path".equals(p.in()) && !requestFields.containsKey(p.name())) {
                        requestFields.put(p.name(), FieldInfo.simple("string", p.required(), p.pointer()));
                    }
                }

                Map<String, Map<String, FieldInfo>> responses = new LinkedHashMap<>();
                JsonNode responsesNode = resolved.path("responses");
                responsesNode.fields().forEachRemaining(respEntry -> {
                    String code = respEntry.getKey();
                    JsonNode schema = respEntry.getValue().path("content").path("application/json").path("schema");
                    Map<String, FieldInfo> fields = new LinkedHashMap<>();
                    if (!schema.isMissingNode()) {
                        flatten(schema, root, "", false, fields,
                                pointer + "/responses/" + escape(code) + "/content/application~1json/schema",
                                new HashSet<>(), 0);
                    }
                    responses.put(code, fields);
                });

                boolean internal = op.path("x-internal").asBoolean(false);
                String sunset = op.path("x-sunset").asText(null);
                operations.add(new OperationModel(method, path, normalized, pathParams, params,
                        requestFields, responses, internal, sunset, pointer));
            });
        });
        return new ApiModel(service, version, operations);
    }

    public ConsumerRegistration parseConsumer(String content) throws Exception {
        JsonNode root = read(content);
        List<String> errors = new ArrayList<>();
        if (root == null || !root.isObject()) {
            errors.add("Consumer file is not a YAML/JSON object");
        } else {
            if (root.path("consumer").asText("").isBlank()) {
                errors.add("Missing 'consumer' name");
            }
            if (!root.path("uses").isArray()) {
                errors.add("Missing 'uses' list");
            }
        }
        if (!errors.isEmpty()) {
            throw new IllegalArgumentException(String.join("; ", errors));
        }
        List<ConsumerUse> uses = new ArrayList<>();
        for (JsonNode u : root.path("uses")) {
            uses.add(new ConsumerUse(u.path("provider").asText(""), u.path("method").asText("").toUpperCase(Locale.ROOT),
                    u.path("path").asText(""), strings(u.path("sends")), strings(u.path("reads"))));
        }
        return new ConsumerRegistration(root.path("consumer").asText(), root.path("team").asText(""), uses);
    }

    private List<String> strings(JsonNode node) {
        List<String> values = new ArrayList<>();
        if (node.isArray()) {
            node.forEach(v -> values.add(v.asText()));
        }
        return values;
    }

    private JsonNode resolve(JsonNode node, JsonNode root, Set<String> visiting, int depth) {
        if (depth > 30 || node == null) {
            return node;
        }
        if (node.isObject() && node.has("$ref")) {
            String ref = node.path("$ref").asText("");
            JsonNode target = pointer(ref, root);
            if (target == null || !visiting.add(ref)) {
                return yaml.createObjectNode();
            }
            JsonNode resolved = resolve(target, root, visiting, depth + 1);
            visiting.remove(ref);
            return resolved;
        }
        if (node.isObject()) {
            ObjectNode copy = yaml.createObjectNode();
            node.fields().forEachRemaining(e -> copy.set(e.getKey(), resolve(e.getValue(), root, visiting, depth + 1)));
            return copy;
        }
        if (node.isArray()) {
            ArrayNode copy = yaml.createArrayNode();
            node.forEach(child -> copy.add(resolve(child, root, visiting, depth + 1)));
            return copy;
        }
        return node.deepCopy();
    }

    private void flatten(JsonNode schema, JsonNode root, String prefix, boolean parentRequired,
                         Map<String, FieldInfo> out, String pointer, Set<String> visiting, int depth) {
        if (depth > 30 || schema == null) {
            return;
        }
        JsonNode node = resolve(schema, root, visiting, depth);
        if (!node.isObject()) {
            return;
        }
        if (node.has("allOf") && node.path("allOf").isArray()) {
            for (JsonNode part : node.path("allOf")) {
                flatten(part, root, prefix, parentRequired, out, pointer + "/allOf", visiting, depth + 1);
            }
        }
        Set<String> required = new HashSet<>();
        JsonNode requiredNode = node.path("required");
        if (requiredNode.isArray()) {
            requiredNode.forEach(r -> required.add(r.asText()));
        }
        if ("array".equals(node.path("type").asText("")) && node.has("items")) {
            String arrayPrefix = prefix.isEmpty() ? "" : prefix + "[]";
            flatten(node.path("items"), root, arrayPrefix, false, out, pointer + "/items", visiting, depth + 1);
        }
        JsonNode properties = node.path("properties");
        if (properties.isObject()) {
            properties.fields().forEachRemaining(entry -> {
                String name = entry.getKey();
                String path = prefix.isEmpty() ? name : prefix + "." + name;
                JsonNode field = entry.getValue();
                String fieldPointer = pointer + "/properties/" + escape(name);
                List<String> enumValues = new ArrayList<>();
                JsonNode enumNode = field.path("enum");
                if (enumNode.isArray()) {
                    enumNode.forEach(v -> enumValues.add(v.asText()));
                }
                Number min = number(field.path("minimum"));
                Number max = number(field.path("maximum"));
                out.put(path, new FieldInfo(field.path("type").asText("object"), required.contains(name),
                        enumValues, min, max, field.path("deprecated").asBoolean(false),
                        field.hasNonNull("x-sunset") ? field.path("x-sunset").asText() : null, fieldPointer));
                flatten(field, root, path, required.contains(name), out, fieldPointer, visiting, depth + 1);
            });
        }
    }

    private Number number(JsonNode node) {
        if (node == null || node.isMissingNode() || node.isNull()) {
            return null;
        }
        if (node.isNumber()) {
            return node.numberValue();
        }
        return null;
    }

    private String escape(String key) {
        return key.replace("~", "~0").replace("/", "~1");
    }
}
