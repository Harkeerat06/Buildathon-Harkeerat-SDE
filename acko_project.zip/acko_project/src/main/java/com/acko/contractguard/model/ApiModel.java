package com.acko.contractguard.model;

import java.util.List;

public record ApiModel(String service, String version, List<OperationModel> operations) {
}
