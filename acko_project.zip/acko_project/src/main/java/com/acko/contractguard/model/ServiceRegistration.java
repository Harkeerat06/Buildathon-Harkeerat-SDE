package com.acko.contractguard.model;

public record ServiceRegistration(long id, String name, ServiceKind kind, String ownerTeam) {
}
