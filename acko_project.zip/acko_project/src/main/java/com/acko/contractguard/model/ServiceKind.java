package com.acko.contractguard.model;

public enum ServiceKind {
    PROVIDER, CONSUMER
}
