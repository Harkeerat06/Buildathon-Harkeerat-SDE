package com.acko.contractguard.publish;

import com.acko.contractguard.diff.Differ;
import com.acko.contractguard.model.*;
import com.acko.contractguard.notify.WebhookNotifier;
import com.acko.contractguard.rules.Classifier;
import com.acko.contractguard.spec.SpecParser;
import com.acko.contractguard.store.Store;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;

@Service
public class PublishService {

    private final SpecParser parser;
    private final Differ differ;
    private final Classifier classifier;
    private final Store store;
    private final WebhookNotifier notifier;
    private final ObjectMapper mapper;

    public PublishService(SpecParser parser, Differ differ, Classifier classifier, Store store,
                          WebhookNotifier notifier, ObjectMapper mapper) {
        this.parser = parser;
        this.differ = differ;
        this.classifier = classifier;
        this.store = store;
        this.notifier = notifier;
        this.mapper = mapper;
    }

    public Decision publishProvider(String service, String version, String fileName, String rawYaml) {
        JsonNode root;
        try {
            root = parser.read(rawYaml);
        } catch (Exception e) {
            return rejected(service, version, "Cannot parse YAML/JSON: " + e.getMessage());
        }
        List<String> errors = parser.validate(root);
        if (!errors.isEmpty()) {
            return rejected(service, version, String.join("; ", errors));
        }
        if (store.hasAcceptedVersion(service, version)) {
            Finding f = new Finding(Severity.CRITICAL, ChangeType.DUPLICATE_VERSION, service,
                    store.ownerOf(service), "version " + version,
                    "Semantic error: version '" + version + "' has already been accepted for " + service
                            + ". A version name must be unique among accepted versions.",
                    List.of(), List.of(store.ownerOf(service)));
            return blocked(service, version, "(none)", List.of(f), List.of());
        }

        SpecVersion baseline = store.lastAccepted(service);
        List<Change> changes = new ArrayList<>();
        if (baseline != null) {
            try {
                changes.addAll(differ.diff(parser.toApiModel(service, parser.read(baseline.rawYaml())),
                        parser.toApiModel(service, root)));
            } catch (Exception e) {
                return rejected(service, version, "Cannot analyse specification: " + e.getMessage());
            }
        }
        List<Finding> findings = classifier.classify(service, changes);
        Outcome outcome = decide(findings);
        SpecStatus status = outcome == Outcome.BLOCKED ? SpecStatus.BLOCKED : SpecStatus.ACCEPTED;
        store.saveSpec(service, version, fileName, rawYaml, status);

        String baselineVersion = baseline == null ? "(none)" : baseline.version();
        String summary = summary(findings);
        Decision decision = new Decision(outcome, service, version, baselineVersion, findings, List.of(), null, summary);
        Attempt attempt = store.saveAttempt(service, version, decision);
        Decision finalDecision = new Decision(outcome, service, version, baselineVersion, findings,
                List.of(), attempt.id(), summary);
        notify(attempt.id(), "API_SPEC", finalDecision);
        return finalDecision;
    }

    public Decision publishConsumer(String name, String team, String rawYaml) {
        ConsumerRegistration registration;
        try {
            registration = parser.parseConsumer(rawYaml);
        } catch (Exception e) {
            return rejected(name, "(consumer)", e.getMessage());
        }
        String consumer = registration.consumer() == null || registration.consumer().isBlank()
                ? name : registration.consumer();
        String consumerTeam = registration.team() == null || registration.team().isBlank()
                ? team : registration.team();

        List<Finding> findings = new ArrayList<>();
        for (ConsumerUse use : registration.uses()) {
            findings.addAll(checkUse(consumer, consumerTeam, use));
        }
        Outcome outcome = decide(findings);
        String summary = summary(findings);
        Decision decision = new Decision(outcome, consumer, "(consumer update)", "(current accepted specs)",
                findings, List.of(), null, summary);
        Attempt attempt = store.saveAttempt(consumer, "(consumer update)", decision);
        if (outcome != Outcome.BLOCKED) {
            store.registerConsumer(consumer, consumerTeam, registration.uses());
        }
        Decision finalDecision = new Decision(outcome, consumer, "(consumer update)", "(current accepted specs)",
                findings, List.of(), attempt.id(), summary);
        notify(attempt.id(), "CONSUMER", finalDecision);
        return finalDecision;
    }

    private List<Finding> checkUse(String consumer, String team, ConsumerUse use) {
        List<Finding> findings = new ArrayList<>();
        SpecVersion baseline = store.lastAccepted(use.provider());
        if (baseline == null) {
            findings.add(new Finding(Severity.WARNING, ChangeType.INVALID_SPEC, use.provider(), consumer,
                    use.method() + " " + use.path(),
                    "No accepted specification is registered for " + use.provider() + "; cannot verify this usage.",
                    List.of(consumer), List.of(team)));
            return findings;
        }
        ApiModel model;
        try {
            model = parser.toApiModel(use.provider(), parser.read(baseline.rawYaml()));
        } catch (Exception e) {
            findings.add(new Finding(Severity.WARNING, ChangeType.INVALID_SPEC, use.provider(), consumer,
                    use.method() + " " + use.path(), "Cannot read the accepted spec: " + e.getMessage(),
                    List.of(consumer), List.of(team)));
            return findings;
        }
        OperationModel op = model.operations().stream()
                .filter(o -> o.key().equalsIgnoreCase(use.method() + " " + normalize(use.path())))
                .findFirst().orElse(null);
        if (op == null) {
            findings.add(new Finding(Severity.WARNING, ChangeType.ENDPOINT_REMOVED, use.provider(), consumer,
                    use.method() + " " + use.path(),
                    "The consumer calls " + use.method() + " " + use.path() + " but no such endpoint exists in the "
                            + "accepted version " + baseline.version() + " of " + use.provider() + ".",
                    List.of(consumer), List.of(team, store.ownerOf(use.provider()))));
            return findings;
        }

        Set<String> available = new HashSet<>(op.requestFields().keySet());
        available.addAll(op.pathParamNames());
        for (String field : use.sends()) {
            if (!available.contains(field)) {
                findings.add(new Finding(Severity.WARNING, ChangeType.FIELD_ADDED, use.provider(), consumer,
                        field, "The consumer sends '" + field + "' which " + use.provider()
                        + " does not declare; it may be ignored. Notify the API team if it should be kept.",
                        List.of(consumer), List.of(team, store.ownerOf(use.provider()))));
            }
        }
        for (Map.Entry<String, FieldInfo> e : op.requestFields().entrySet()) {
            if (e.getValue().required() && !use.sends().contains(e.getKey())) {
                findings.add(new Finding(Severity.CRITICAL, ChangeType.FIELD_REMOVED, use.provider(), consumer,
                        e.getKey(), "The accepted " + use.provider() + " spec requires '" + e.getKey()
                        + "' but the consumer no longer sends it. The service team must notify the API team "
                        + "before requesting this change.",
                        List.of(consumer), List.of(store.ownerOf(use.provider()), team)));
            }
        }
        Set<String> responseFields = new HashSet<>();
        op.responses().values().forEach(fields -> responseFields.addAll(fields.keySet()));
        for (String field : use.reads()) {
            if (!responseFields.contains(field)) {
                findings.add(new Finding(Severity.WARNING, ChangeType.FIELD_REMOVED, use.provider(), consumer,
                        field, "The consumer reads '" + field + "' which is not returned by " + use.provider()
                        + " " + op.key() + " in version " + baseline.version() + ".",
                        List.of(consumer), List.of(team, store.ownerOf(use.provider()))));
            }
        }
        return findings;
    }

    private void notify(long attemptId, String kind, Decision decision) {
        Set<String> teams = new TreeSet<>();
        for (Finding f : decision.findings()) {
            teams.addAll(f.notifyTeams());
        }
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("kind", kind);
        payload.put("outcome", decision.outcome().name());
        payload.put("service", decision.service());
        payload.put("version", decision.version());
        payload.put("comparisonBaseline", decision.baselineVersion());
        payload.put("reason", decision.summary());
        payload.put("reviewId", decision.reviewId());
        payload.put("notifiedTeams", new ArrayList<>(teams));
        payload.put("findings", decision.findings());
        payload.put("errors", decision.errors());
        payload.put("at", Instant.now().toString());
        boolean delivered = notifier.send(payload);
        payload.put("webhookDelivered", delivered);
        try {
            store.saveNotification(attemptId, mapper.writeValueAsString(payload));
        } catch (Exception ignored) {
            // notification logging must not fail the publish
        }
    }

    private Decision rejected(String service, String version, String reason) {
        Finding f = new Finding(Severity.CRITICAL, ChangeType.INVALID_SPEC, service, store.ownerOf(service),
                "upload", "Rejected: " + reason, List.of(), List.of(store.ownerOf(service)));
        store.saveSpec(service, version, "(upload)", "", SpecStatus.REJECTED);
        Decision decision = new Decision(Outcome.REJECTED, service, version, "(none)", List.of(f),
                List.of(reason), null, "REJECTED: " + reason);
        Attempt attempt = store.saveAttempt(service, version, decision);
        Decision finalDecision = new Decision(Outcome.REJECTED, service, version, "(none)", List.of(f),
                List.of(reason), attempt.id(), "REJECTED: " + reason);
        notify(attempt.id(), "UPLOAD_ERROR", finalDecision);
        return finalDecision;
    }

    private Decision blocked(String service, String version, String baseline, List<Finding> findings,
                             List<String> errors) {
        store.saveSpec(service, version, "(upload)", "", SpecStatus.BLOCKED);
        String summary = summary(findings);
        Decision decision = new Decision(Outcome.BLOCKED, service, version, baseline, findings, errors, null, summary);
        Attempt attempt = store.saveAttempt(service, version, decision);
        Decision finalDecision = new Decision(Outcome.BLOCKED, service, version, baseline, findings, errors,
                attempt.id(), summary);
        notify(attempt.id(), "API_SPEC", finalDecision);
        return finalDecision;
    }

    private Outcome decide(List<Finding> findings) {
        for (Finding f : findings) {
            if (f.severity() == Severity.CRITICAL) {
                return Outcome.BLOCKED;
            }
        }
        return findings.isEmpty() ? Outcome.SAFE : Outcome.WARN;
    }

    private String summary(List<Finding> findings) {
        if (findings.isEmpty()) {
            return "SAFE: no breaking or notable changes found.";
        }
        long critical = findings.stream().filter(f -> f.severity() == Severity.CRITICAL).count();
        long warning = findings.stream().filter(f -> f.severity() == Severity.WARNING).count();
        long notice = findings.stream().filter(f -> f.severity() == Severity.NOTICE).count();
        return critical + " CRITICAL, " + warning + " WARNING, " + notice + " NOTICE finding(s).";
    }

    private String normalize(String path) {
        return path.replaceAll("\\{[^}]+\\}", "{}");
    }
}
