package com.acko.contractguard.model;

import java.util.List;

public record Finding(
        Severity severity,
        ChangeType type,
        String api,
        String service,
        String field,
        String reason,
        List<String> affectedConsumers,
        List<String> notifyTeams
) {
}
