package com.acko.contractguard.model;

public enum Severity {
    CRITICAL, WARNING, NOTICE, INFO
}
