package com.acko.contractguard.rules;

import com.acko.contractguard.model.*;
import com.acko.contractguard.store.Store;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class Classifier {

    private final Store store;

    public Classifier(Store store) {
        this.store = store;
    }

    public List<Finding> classify(String service, List<Change> changes) {
        List<Finding> findings = new ArrayList<>();
        String owner = store.ownerOf(service);
        Set<String> providerTeams = new TreeSet<>();
        for (ConsumerRegistration c : store.listConsumers()) {
            for (ConsumerUse u : c.uses()) {
                if (service.equals(u.provider())) {
                    providerTeams.add(c.team());
                }
            }
        }
        Set<String> seen = new LinkedHashSet<>();
        for (Change change : changes) {
            Finding finding = classifyOne(service, owner, providerTeams, change);
            String key = finding.severity() + "|" + finding.type() + "|" + finding.api() + "|"
                    + finding.field();
            if (seen.add(key)) {
                findings.add(finding);
            }
        }
        return findings;
    }

    private Finding classifyOne(String service, String owner, Set<String> providerTeams, Change change) {
        String operation = operationOf(change);
        List<ConsumerRegistration> using = consumersOf(service, operation);
        Set<String> affected = new TreeSet<>();
        Set<String> accessedTeams = new TreeSet<>();
        for (ConsumerRegistration c : using) {
            for (ConsumerUse u : c.uses()) {
                if (accessed(u, change)) {
                    affected.add(c.consumer());
                    accessedTeams.add(c.team());
                }
            }
        }
        boolean accessed = !affected.isEmpty();
        Set<String> serviceTeams = accessed ? accessedTeams : providerTeams;

        if (change.internal()) {
            return new Finding(Severity.INFO, change.type(), service, "internal operation", change.key(),
                    "Change on an internal operation (" + operation + "): " + change.describe()
                            + ". Internal operations are excluded from consumer impact checks.",
                    List.of(), List.of(owner));
        }

        Severity severity;
        Set<String> notify = new TreeSet<>();
        String why;

        switch (change.type()) {
            case INVALID_SPEC, DUPLICATE_VERSION -> {
                severity = Severity.CRITICAL;
                notify.add(owner);
                why = change.describe();
            }
            case SUNSET_DATE_SET_PAST -> {
                severity = Severity.CRITICAL;
                notify.add(owner);
                why = "The new version sets a sunset date in the past. " + change.describe()
                        + ". Extend the sunset date before publishing.";
            }
            case FIELD_ENUM_CHANGED -> {
                Set<String> before = values(change.oldValue());
                Set<String> after = values(change.newValue());
                boolean onlyAdded = after.containsAll(before);
                severity = onlyAdded ? Severity.NOTICE : Severity.WARNING;
                notify.addAll(onlyAdded ? Set.of(owner) : serviceTeams);
                if (onlyAdded) {
                    notify.addAll(serviceTeams);
                }
                why = change.describe() + (onlyAdded
                        ? ". Allowed values were only added, so existing callers remain valid; informational."
                        : ". Consumer files do not record allowed values, so impact cannot be proven; treated as a warning.");
            }
            case PARAMETER_RENAMED, FIELD_TYPE_CHANGED, FIELD_REQUIRED_CHANGED,
                 FIELD_CONSTRAINT_CHANGED, ELEMENT_REMOVED_BEFORE_SUNSET -> {
                severity = accessed ? Severity.CRITICAL : Severity.WARNING;
                notify.addAll(accessed ? Set.of(owner) : serviceTeams);
                why = change.describe() + (accessed
                        ? ". " + String.join(", ", affected) + " uses this field, so it breaks immediately."
                        : ". No registered service accesses it, so deployment can continue with a warning.");
            }
            case ENDPOINT_REMOVED, FIELD_REMOVED, ELEMENT_REMOVED_AFTER_SUNSET -> {
                severity = accessed ? Severity.CRITICAL : Severity.WARNING;
                notify.addAll(accessed ? Set.of(owner) : serviceTeams);
                why = change.describe() + (accessed
                        ? ". " + String.join(", ", affected) + " accesses it, so the update is blocked."
                        : ". No registered service accesses it; deployment is allowed with a warning.");
            }
            case PARAMETER_ADDED -> {
                boolean required = "required".equals(change.oldValue());
                severity = required ? Severity.CRITICAL : Severity.NOTICE;
                notify.addAll(required ? Set.of(owner) : serviceTeams);
                why = change.describe() + (required
                        ? ". The parameter is required but no registered service sends it."
                        : ". The parameter is optional, so existing callers are safe.");
            }
            case SUNSET_DATE_PAST -> {
                severity = accessed ? Severity.CRITICAL : Severity.WARNING;
                notify.addAll(accessed ? Set.of(owner) : serviceTeams);
                why = change.describe() + (accessed
                        ? ". A service still accesses it; the API team must act before deployment."
                        : ". No service accesses it; only a warning is needed.");
            }
            case SUNSET_DATE_FUTURE -> {
                severity = Severity.WARNING;
                notify.addAll(serviceTeams);
                why = change.describe() + ". Warning sent in advance; nothing breaks yet.";
            }
            case FIELD_ADDED -> {
                boolean requiredRequestField = change.side().startsWith("Request")
                        && change.newValue() != null && change.newValue().contains("(required)");
                severity = requiredRequestField ? Severity.CRITICAL : Severity.NOTICE;
                notify.add(owner);
                if (!requiredRequestField) {
                    notify.addAll(serviceTeams);
                }
                why = requiredRequestField
                        ? change.describe() + ". A new required request field is not sent by registered "
                            + "consumers, so the deployment is blocked and the API team must act."
                        : change.describe() + ". Extra data is non-breaking; both teams are informed.";
            }
            case STATUS_CODE_ADDED, ENDPOINT_ADDED -> {
                severity = Severity.NOTICE;
                notify.add(owner);
                notify.addAll(serviceTeams);
                why = change.describe() + ". No registered service is affected.";
            }
            case STATUS_CODE_REMOVED -> {
                severity = Severity.WARNING;
                notify.addAll(serviceTeams);
                why = change.describe() + ". Consumer files do not record status codes, so impact cannot be proven; treat as a warning.";
            }
            default -> {
                severity = Severity.WARNING;
                notify.addAll(serviceTeams);
                why = change.describe();
            }
        }

        String detail = why + " API: " + service + ". Operation: " + operation + ". "
                + "Specification location: " + change.pointer() + ".";
        return new Finding(severity, change.type(), service,
                affected.isEmpty() ? String.join(", ", serviceTeams) : String.join(", ", affected),
                change.key(), detail, new ArrayList<>(affected), new ArrayList<>(notify));
    }

    private Set<String> values(String text) {
        Set<String> result = new HashSet<>();
        if (text == null) {
            return result;
        }
        String cleaned = text.replace("[", "").replace("]", "");
        for (String part : cleaned.split(",")) {
            String value = part.trim();
            if (!value.isEmpty()) {
                result.add(value);
            }
        }
        return result;
    }

    private List<ConsumerRegistration> consumersOf(String service, String operation) {
        List<ConsumerRegistration> result = new ArrayList<>();
        if (operation == null) {
            return result;
        }
        for (ConsumerRegistration c : store.listConsumers()) {
            for (ConsumerUse u : c.uses()) {
                if (service.equals(u.provider())
                        && operation.equalsIgnoreCase(u.method().toUpperCase(Locale.ROOT) + " " + normalize(u.path()))) {
                    result.add(c);
                    break;
                }
            }
        }
        return result;
    }

    private boolean accessed(ConsumerUse use, Change change) {
        if (change.side().startsWith("Request")) {
            return use.sends().contains(change.key());
        }
        if (change.side().startsWith("Response")) {
            return use.reads().contains(change.key());
        }
        return false;
    }

    private String operationOf(Change change) {
        String p = change.pointer();
        if (p == null || !p.startsWith("#/paths/")) {
            return null;
        }
        String[] parts = p.substring("#/paths/".length()).split("/", 3);
        if (parts.length < 2) {
            return null;
        }
        String path = parts[0].replace("~1", "/").replace("~0", "~");
        return parts[1].toUpperCase(Locale.ROOT) + " " + normalize(path);
    }

    private String normalize(String path) {
        return path.replaceAll("\\{[^}]+\\}", "{}");
    }
}
