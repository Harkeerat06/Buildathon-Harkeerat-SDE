# Contract Guard

## Introduction

Contract Guard is an API contract registry that stops a team's API change from silently
breaking the services that call it. Teams publish each version of their OpenAPI specification
into the registry; Contract Guard works out exactly what changed between versions — comparing
what the API actually accepts and returns rather than how the files are written — checks those
changes against the fields each consuming service sends and reads, and decides whether the new
version is safe to publish.

If a change would break a consumer, Contract Guard blocks the publish, records it for review,
and notifies the responsible teams with a full explanation: what changed, why it is dangerous,
which API and field are involved, the exact location in the specification, and which services
and teams are affected. Changes that are noticeable but not breaking are allowed through with a
warning, so nobody has to rely on assumptions later.

The three provider APIs in the starter kit are `quote-api`, `policy-api` and `claims-api`.
The four consumer services are `mobile-app`, `partner-portal`, `payments-svc` and
`notifications-svc`.

## What it does

- Registers services and their owner teams, and stores every uploaded specification version.
- Validates an uploaded YAML/JSON specification and rejects invalid ones with a clear error
  (including unresolved `$ref` references).
- Resolves `$ref` components so renaming or reorganising components does not look like a wire
  change, then compares the effective API against the **last accepted** version.
- Detects added/removed endpoints and methods, parameters, nested request/response fields
  (including lists with `[]`), type changes, requiredness, enums, constraints and status codes.
- Classifies each change as CRITICAL, WARNING, NOTICE or INFO and returns
  **BLOCKED / WARN / SAFE**.
- Provides a consumer-side upload: a service can submit a changed consumer YAML and see
  whether its own update would break the API contract.
- Sends detailed notifications to the webhook receiver (the stand-in for chat/email).
- Keeps a changelog between any two versions and a history of every publish attempt.
- Shows metrics such as dangerous changes caught, blocked publishes and notifications sent.

Built with **Java 17+, Spring Boot 4, Maven, Jackson YAML, Thymeleaf and H2**.

## Project layout

```
pom.xml                     Maven build
Dockerfile                  Container image for the app
docker-compose.yml          Starts the app and the webhook receiver together
src/main/java/.../           Application source (spec, diff, rules, publish, notify, store, web)
src/main/resources/          Thymeleaf templates, CSS, application.properties
src/test/java/.../           Unit tests
contract-guard-starter-kit/  Original, unmodified kit: specs, consumers, webhook receiver
md_files/                    PLAN.md, DECISIONS.md, PROGRESS.md, REVIEW.md
```

## Setup guide — run it from scratch

### 1. Option A — one command with Docker (recommended)

From this project's root folder:

```bash
docker compose up --build
```

Or with Podman: `podman compose up --build` (make sure the Podman machine is running).

This starts both containers: **Contract Guard** at <http://localhost:8080> and the **webhook
receiver** at <http://localhost:9900>. The app is configured to send notifications to the
receiver automatically. If either port is already in use, override it, for example:

```bash
WEBHOOK_PORT=9950 APP_PORT=8081 docker compose up --build
```

### 2. Option B — run locally with Maven

Prerequisites: **JDK 17 or newer** (verified with Java 25) and **Maven 3.9+**.

```bash
java -version
mvn -version
```

Start the webhook receiver first. Either from the kit folder:

```bash
cd contract-guard-starter-kit
docker compose up --build
```

Or directly with Python 3 (no Docker needed):

```bash
cd contract-guard-starter-kit/webhook-receiver
PORT=9000 python3 app.py
```

Open <http://localhost:9900> to see received notifications. If port 9900 is taken, use
`WEBHOOK_PORT=9950 docker compose up --build` in the kit folder.

Then, from this project's root folder, start Contract Guard:

```bash
mvn spring-boot:run
```

The app starts on <http://localhost:8080> and expects the webhook at
`http://localhost:9900/contract-guard`. If you changed the webhook port:

```bash
WEBHOOK_URL=http://localhost:9950/contract-guard mvn spring-boot:run
```

To build and run the packaged jar instead:

```bash
mvn clean package
java -jar target/contract-guard-1.0.0.jar
```

### 3. First run in the UI

1. Open <http://localhost:8080>.
2. Click **Import services & consumers** — this reads the original kit files read-only and
   registers the three provider teams and four consumer services.
3. Click **Replay all spec versions** — this uploads the twelve specifications in filename
   order and records the outcome of each attempt.
4. Check **History & review** for the explanations and the full notifications, and the
   webhook page to see what the teams would have received.

To try your own file, use **Upload API spec** (choose a service and a YAML/JSON file) or
**Upload consumer** (a consumer YAML file). Each shows SAFE, WARN or BLOCKED, the findings,
the affected services, the specification location, the teams notified and any upload errors.

### 4. Run the tests

```bash
mvn test
```

### 5. Using the REST API

| Endpoint | Purpose |
|---|---|
| `POST /api/services?name=&kind=PROVIDER\|CONSUMER&team=` | Register a service |
| `POST /api/specs/upload?service=<name>` (multipart `file`) | Check and publish a spec version |
| `POST /api/consumers/upload?team=<team>` (multipart `file`) | Check a consumer update |
| `GET /api/specs/{service}/versions` | List versions with statuses |
| `GET /api/specs/{service}/diff?from=&to=` | Diff any two versions |
| `GET /api/history`, `/api/review-queue` | Publish attempts and blocked attempts |
| `GET /api/consumers`, `/api/metrics` | Consumer registry and metrics |

Example:

```bash
curl -X POST -F 'service=quote-api' \
     -F 'file=@contract-guard-starter-kit/specs/quote-api/1-initial.yaml' \
     http://localhost:8080/api/specs/upload
```

### 6. Resetting the data

State is stored in an H2 file under `./data/`. To start clean, stop the app and delete that
folder. The starter kit files themselves are never modified.

## Rules in brief

- Compare with the **last accepted** version only; rejected and blocked versions never
  become the baseline.
- An accepted version name that is reused is a semantic error and blocks deployment.
- A field or parameter removed or changed while a service accesses it blocks deployment and
  notifies the API owner team. The same change on something nobody uses is a warning to the
  service team.
- Added fields are informational (both teams for response additions, the service team for
  request extras). A newly required request field that consumers do not send blocks.
- `x-internal` operations are excluded from consumer-impact checks. `x-sunset` dates drive
  warnings and blocks according to the decision log.
- Invalid specifications are rejected with the exact problem reported back to the user.

Full reasoning and timestamps are in `md_files/DECISIONS.md`; the plan, progress note and
self-review are in the same folder.

## Scope and limitations

The ten must-have features are implemented. AI-generated migration guides and a separate CI
CLI check are intentionally left out (they are "going further" items). Enum values and status
codes are not recorded in the consumer files, so those changes can only be warnings. Webhook
delivery is best-effort and recorded in the notification payload.
